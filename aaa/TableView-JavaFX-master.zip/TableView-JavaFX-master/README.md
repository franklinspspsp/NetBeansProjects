# TableView-JavaFX
Uso del control TableView en JavaFX

Más información en: [TableView en JavaFX](http://acodigo.blogspot.com/2015/08/tableview-control-javafx.html)
